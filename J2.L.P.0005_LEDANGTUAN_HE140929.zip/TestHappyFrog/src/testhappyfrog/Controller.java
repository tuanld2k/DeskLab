/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhappyfrog;

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import sun.swing.ImageIconUIResource;

/**
 *
 * @author nguoitamxa
 */
public class Controller {

    displayFrog frameFrog = new displayFrog();
    //C:\Users\nguoitamxa\Documents\NetBeansProjects\TestHappyFrog\src\testhappyfrog\frog.png
    ImageIcon imageFrog = new ImageIcon("./src/testhappyfrog/frog.png");

    JButton btnFrog = new JButton(imageFrog);

    ArrayList<JButton> listbtnPipes = new ArrayList<>();

    int yFrog;
    int countup = 200;
    int score = 0;
    boolean isSave = false;
    Random rd = new Random();

    int xPipe = frameFrog.getPanel().getWidth();
    int yPipe = frameFrog.getPanel().getHeight();
    int hPipel = 2 * (yPipe / 9) + rd.nextInt(yPipe / 9);
    int hPipel_up2 = 3 * (yPipe / 9) + rd.nextInt(yPipe / 9);
    int hPipel_down2 = 2 * yPipe / 3 - hPipel_up2;
    int hPipel_down = 2 * yPipe / 3 - hPipel;

    int wPipel = 40;

    Timer timeFrog;
    Timer timeUp;

    public Controller() {

        frameFrog.getPanel().add(btnFrog);
        frameFrog.setVisible(true);

        moveFrog();
        movePipe();
        createPipes();

        btnFrog.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                yFrog = yFrog - 15;
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });

        frameFrog.getBtnPause().addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                yFrog = yFrog - 15;
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });

        frameFrog.getBtnSave().addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                yFrog = yFrog - 15;
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });

        frameFrog.getBtnPause().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (timeFrog.isRunning()) {
                    stoptimer();
                    frameFrog.getBtnPause().setText("Resume");
                } else {
                    frameFrog.getBtnPause().setText("Pause");
                    restart_timer();
                }
            }

        });

        frameFrog.getBtnSave().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                isSave = true;
                try {
                    FileWriter MyFileWriter = new FileWriter("RecordScore.txt");
                    for (JButton btnup : listbtnPipes) {
                        int xUp = btnup.getX();
                        int yUp = btnup.getY();
                        int wUp = btnup.getWidth();
                        int hUp = btnup.getHeight();
                        MyFileWriter.write(xUp + "," + yUp + "," + wUp + "," + hUp + "\n");
                    }

                    int yFrog = btnFrog.getY();
                    MyFileWriter.write(yFrog + "," + score);
                    MyFileWriter.close();
                } catch (IOException ex) {
                    Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });

        frameFrog.getBtnExit().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }

        });

    }

    String giveMedal(int number) {
        if (number >= 40) {
            return "Your Score: " + number + "\nPlatinum medal";
        }
        if (number >= 30) {
            return "Your Score: " + number + "\nGold medal";
        }
        if (number >= 20) {
            return "Your Score: " + number + "\nSilver medal";
        }
        if (number >= 10) {
            return "Your Score: " + number + "\nBronze medal";
        }
        return "Your Score: " + number + "\nNo medal";

    }

    public void moveFrog() {
        timeFrog = new Timer(20, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                yFrog= yFrog*1.001;
                btnFrog.setBounds(40, yFrog++, 40, 40);

                countScore();

                if (stopFrog()) {
                    stoptimer();
                    if (!isSave) {
                        String mes[] = {"New Game", "Exit"};
                        int choice = JOptionPane.showOptionDialog(null, giveMedal(score / 2), "", 0, 0, null, mes, null);

                        if (choice == 0) {
                            frameFrog.getPanel().removeAll();
                            listbtnPipes.clear();
                            frameFrog.getPanel().repaint();
                            createPipes();
                            yFrog = 0;
                            score = 0;
                            frameFrog.getPanel().add(btnFrog);
                            frameFrog.getLblScore().setText("Point: 0");
                            start_timer();
                        }

                        if (choice == 1) {
                            System.exit(0);
                        }
                    } else {
                        String[] options = {"New Game", "Continue", "Exit"};
                        int choice = JOptionPane.showOptionDialog(null, giveMedal(score / 2), "", 0, 0, null, options, null);

                        if (choice == 0) {
                            // remove all component from panel
                            frameFrog.getPanel().removeAll();
                            // remove all data in list
                            listbtnPipes.clear();
                            // call the repaint method to update the new appearance 
                            // of the component on the graphical user interface.
                            frameFrog.getPanel().repaint();
                            createPipes();
                            yFrog = 0;
                            score = 0;
                            frameFrog.getPanel().add(btnFrog);
                            frameFrog.getLblScore().setText("Point: 0");
                            start_timer();
                        }

                        if (choice == 1) {
                            frameFrog.getPanel().removeAll();

                            // call the repaint method to update the new appearance 
                            // of the component on the graphical user interface.
                            frameFrog.getPanel().repaint();

                            // remove all data in list
                            listbtnPipes.clear();

                            try {
                                FileReader MyFileReader = new FileReader("RecordScore.txt");
                                BufferedReader br = new BufferedReader(MyFileReader);
                                String line = "";
                                do {
                                    line = br.readLine();
                                    if (line == null) {
                                        break;
                                    }
                                    JButton btn = new JButton();
                                    String txt[] = line.split(",");
                                    int arr[] = new int[txt.length];
                                    for (int i = 0; i < arr.length; i++) {
                                        arr[i] = Integer.parseInt(txt[i]);
                                    }
                                    if (arr.length == 4) {
                                        btn.setBounds(arr[0], arr[1], arr[2], arr[3]);
                                        listbtnPipes.add(btn);
                                        frameFrog.getPanel().add(btn);
                                    } else {
                                        yFrog = arr[0];
                                        score = arr[1];
                                        frameFrog.getLblScore().setText("Point: " + score / 2);
                                    }
                                } while (true);
                                br.close();
                            } catch (IOException ex) {
                            }
                            frameFrog.getPanel().add(btnFrog);
                            start_timer();
                        }

                        if (choice == 2) {
                            System.exit(0);
                        }
                    }
                }
            }
        });
        timeFrog.start();
    }

    public void createPipes() {
        JButton btnUpPipe = new JButton();
        JButton btnDownPipe = new JButton();
        JButton btnUpPipe2 = new JButton();
        JButton btnDownPipe2 = new JButton();

        btnUpPipe.setBounds(xPipe, 0, wPipel, hPipel);
        btnUpPipe2.setBounds(xPipe + 200, 0, wPipel, hPipel_up2);

        btnDownPipe.setBounds(xPipe, hPipel + yPipe / 3, wPipel, hPipel_down);

        btnDownPipe2.setBounds(xPipe + 200, hPipel_up2 + yPipe / 3, wPipel, hPipel_down2);

        frameFrog.getPanel().add(btnUpPipe);
        frameFrog.getPanel().add(btnDownPipe);
        frameFrog.getPanel().add(btnUpPipe2);
        frameFrog.getPanel().add(btnDownPipe2);

        listbtnPipes.add(btnUpPipe);
        listbtnPipes.add(btnDownPipe);
        listbtnPipes.add(btnUpPipe2);
        listbtnPipes.add(btnDownPipe2);
        System.out.print("Old1: " + hPipel + " " + hPipel_down + "\n" + "Old2: " + hPipel_up2 + " " + hPipel_down2);

    }

    public void movePipe() {
        timeUp = new Timer(20, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < listbtnPipes.size(); i++) {
                    int x = listbtnPipes.get(i).getX();
                    int y = listbtnPipes.get(i).getY();
                    listbtnPipes.get(i).setLocation(--x, y);

                    if (x <= -40) {
                        // update new height from old height and random value
                        int newUpheight = hPipel + rd.nextInt(yPipe / 9);
                        int newDownheight = 2 * yPipe / 3 - newUpheight;
                        // set up random for Up pair pipes in list
                        if (i % 2 == 0) {
                            System.out.print("\nNew:" + newUpheight + " " + newDownheight);
                            listbtnPipes.get(i).setBounds(frameFrog.getPanel().getWidth(), y, wPipel, newUpheight);
                            listbtnPipes.get(i + 1).setBounds(frameFrog.getPanel().getWidth(), newUpheight + yPipe / 3, wPipel, newDownheight);
                        } // set up random for Down pair pipes in list
                    }
                }
            }
        });
        timeUp.start();
    }

    boolean stopFrog() {
        if (yFrog <= 0 || yFrog >= frameFrog.getPanel().getHeight() - 40) {
            return true;
        }
        for (JButton btnup : listbtnPipes) {
            Rectangle recF = new Rectangle(btnFrog.getX(), yFrog, btnFrog.getWidth(), btnFrog.getHeight());
            Rectangle recColup = new Rectangle(btnup.getX(), btnup.getY(), btnup.getWidth(), btnup.getHeight());
            if (recF.intersects(recColup)) {
                return true;
            }
        }
        return false;

    }

    public void countScore() {
        for (JButton listPipe : listbtnPipes) {
            if (listPipe.getX() == btnFrog.getX()) {
                score++;
                frameFrog.getLblScore().setText("Point: " + score / 2);
            }
        }
    }

    public void start_timer() {
        timeFrog.start();
        timeUp.start();
    }

    public void stoptimer() {
        timeFrog.stop();
        timeUp.stop();
    }

    public void restart_timer() {
        timeFrog.restart();
        timeUp.restart();;
    }
}
